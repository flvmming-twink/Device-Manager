package com.example.contactmanagerdemo.data

data class Contact(
    val id: Long,
    val name: String,
    val lastName: String? = null,
    val phone: String,
    val email: String? = null,
    val address: String? = null,
    val birthday: String? = null,
    val comment: String? = null,
    val avatarColor: String? = null,
    val avatarPhotoUri: String? = null,
    val group: String,
    val isFavorite: Boolean = false,
    val isImported: Boolean = false,
)
